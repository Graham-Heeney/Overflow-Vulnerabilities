#include <stdio.h>
#include <string.h>
int main() {
   char destination[15] = "Hello ";
   char source[10] = "World!";
   strcat(destination, source);
   printf("%s\n", destination);
   return 0;
}