#include <stdio.h>
#include <string.h>
int main() {
    char str1[20] = "Hello, ";
    char str2[] = "world!";
    //creating the max length for the strncpy function
    int maxLength = 20;
    printf("Before concatenation: %s\n", str1);
    //setting the destination, source and the boundaries
    strncat(str1, str2, maxLength);
    printf("After concatenation: %s\n", str1);
    return 0;
}
