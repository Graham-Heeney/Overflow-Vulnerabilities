#include <stdio.h>
#include <string.h>

int main(void)
{
    //password is only set to a length of 15
    char password[15];
    int pass = 0;
    printf("\n Enter the password : \n");
    fgets(password, sizeof(password), stdin);
    //strcmp is used to compare 2 strings.
    if(strcmp(password, "SETU"))
    {
        printf ("\n Wrong Password \n");
    }
    else
    {
        printf ("\n Correct Password \n");
        pass = 1;
    }
    if(pass)
    {
        //Gives root access to the user
        printf ("\n Root privileges given to the user \n");
    }
    return 0;
}
