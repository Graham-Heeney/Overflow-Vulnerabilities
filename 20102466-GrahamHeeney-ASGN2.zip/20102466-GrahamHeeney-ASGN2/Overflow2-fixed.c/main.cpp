#include <iostream>

#include <stdio.h>
#include <string.h>

int main() {
    char src[] = "Hello, World!";
    char dest[20];

    //strncpy now added to check bounds
    strncpy(dest, src, sizeof(dest) - 1);
    //0 added to ensure termination
    dest[sizeof(dest) - 1] = '\0';

    printf("Copied string: %s\n", dest);

    return 0;
}
